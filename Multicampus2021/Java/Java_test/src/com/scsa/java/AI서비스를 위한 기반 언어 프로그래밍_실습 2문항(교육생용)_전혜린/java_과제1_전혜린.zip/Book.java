package com.scsa.java.fifth;

public class Book {
	
	String isbn;
	String title;
	String author;
	String publisher;
	int price;
	String desc;
	
	
	public String toString() {
		return isbn+"|"+title+"|"+author+"|"+publisher+"|"+price+"|"+desc;
		
	}

}
